#include <iostream>
using namespace std;



enum enGameChosse { Stone = 1, Paper = 2, Scissors = 3 };

enum enWinner { Player1 = 1, Bot = 2, Draw = 3 };

struct stRoundInfo
{
	short GameRound;
	enGameChosse PlayerChosse;
	enGameChosse BotChoice;
	enWinner  Winner;
	string NameWinner = "";

};

struct stGameResult
{
	short GameRounds;
	short PlayerWinTime;
	short BotWinTime;
	short DarwTime;
	enWinner GameWinner;
	string NameWinner = "";

};

short RandomNumber(int From, int To)
{
	int RandNum = rand() % (To - From + 1) + From;

	return RandNum;

}

short ReadNumberInRange()
{
	short N = 0;

	do
	{

		cout << " Please Enter Number Of Rounds From 1 To 10 : " << endl;
		cin >> N;


	} while (N < 1 || N > 10);


	return N;


}

enGameChosse ReadPlayerChoice()
{

	short PlayerChoice = 0;
	do
	{


		cout << " Enter Your Choice [1]Stone.[2]Paper.[3]Scissors : " << endl;
		cin >> PlayerChoice;

	} while (PlayerChoice < 1 || PlayerChoice > 3);

	return (enGameChosse)PlayerChoice;
}

enGameChosse GetBotChoice()
{

	return (enGameChosse)RandomNumber(1, 3);


}

enWinner  WhoWonTheRound(enWinner Winner)
{

	stRoundInfo RoundInfo;

	if (RoundInfo.BotChoice == RoundInfo.PlayerChosse)
	{
		return enWinner::Draw;

	}
	switch (RoundInfo.Winner)
	{
	case enGameChosse::Stone:
		if (RoundInfo.BotChoice == enGameChosse::Paper)
		{
			return enWinner::Bot;
			break;
		}
	case  enGameChosse::Paper:
		if (RoundInfo.BotChoice == enGameChosse::Scissors)
		{

			return enWinner::Bot;
			break;

		}
	case enGameChosse::Scissors:
		if (RoundInfo.BotChoice == enGameChosse::Stone)
		{
			return enWinner::Bot;
			break;

		}
		else return enWinner::Player1;
	}

}

enWinner WhoWonTheGame(short PlayerWinTimes, short BotWinTimes)
{


	if (PlayerWinTimes > BotWinTimes)
	{

		return enWinner::Player1;

	}
	else if (PlayerWinTimes < BotWinTimes)
	{
		return enWinner::Bot;
	}
	else return enWinner::Draw;


}

string NameWinnerOnRound(enWinner Winner)
{


	string arrNameWinner[100] = { "Player1" , "Bot" ,"No Winner" };
	return arrNameWinner[Winner - 1];


}

string NameWinnerOnGame(enWinner Winner)
{


	string arrNameWinner[100] = { "Player1" , "Bot" ,"No Winner" };
	return arrNameWinner[Winner - 1];


}

stGameResult PlayGame(short HowManyRounds)
{

	stRoundInfo RoundInfo;

	short PlayerWinTimes = 0, BotWinTimes = 0, DrawTimes = 0;
	for (int i = 1; i <= HowManyRounds; i++)
	{
		RoundInfo.GameRound = HowManyRounds;
		RoundInfo.PlayerChosse = ReadPlayerChoice();
		RoundInfo.BotChoice = GetBotChoice();
		RoundInfo.Winner = WhoWonTheRound(RoundInfo.Winner);
		RoundInfo.NameWinner = NameWinnerOnRound(RoundInfo.Winner);


	}
	if (RoundInfo.PlayerChosse == enWinner::Player1)
	{

		PlayerWinTimes++;

	}
	else if (RoundInfo.PlayerChosse == enWinner::Bot)
	{

		BotWinTimes++;
	}
	else
		DrawTimes++;


	return FillGameResult(HowManyRounds, PlayerWinTimes, BotWinTimes, DrawTimes);


}

string Tabs(short NumberOfTabs)
{

	string t = "";
	for (int i = 0; i <= NumberOfTabs; i++)
	{

		t = t + "\t";

	}

	return t;

}

stGameResult FillGameResult(short HowManyRounds, short PlayerWinTimes, short BotWinTimes, short DrawTimes)
{

	stGameResult GameResult;
	GameResult.GameRounds = HowManyRounds;
	GameResult.PlayerWinTime = PlayerWinTimes;
	GameResult.BotWinTime = BotWinTimes;
	GameResult.DarwTime = DrawTimes;
	GameResult.GameWinner = WhoWonTheGame(PlayerWinTimes, BotWinTimes);
	GameResult.NameWinner = NameWinnerOnGame(GameResult.GameWinner);


	return GameResult;


}

void PrintRoundInfo()
{
	stRoundInfo RoundInfo;


	for (int i = 1; i <= RoundInfo.GameRound; i++)
	{
		cout << Tabs(2) << "________Round[" << i << "]________";
		cout << Tabs(2) << " Player Choice : " << RoundInfo.PlayerChosse << endl;
		cout << Tabs(2) << " Bot Choice : " << RoundInfo.BotChoice << endl;
		cout << Tabs(2) << " Name Winner : " << RoundInfo.NameWinner << endl;
		cout << Tabs(2) << "____________________________" << endl;


	}

}

void PrintGameResult()
{

	stGameResult GameResult;

	cout << Tabs(2) << "_______________[ Game Result ]_______________" << endl;
	cout << Tabs(2) << " Game Rounds : " << GameResult.GameRounds << endl;
	cout << Tabs(2) << " Player1 Won Times : " << GameResult.PlayerWinTime << endl;
	cout << Tabs(2) << " Bot Won Times : " << GameResult.BotWinTime << endl;
	cout << Tabs(2) << " Draw Times : " << GameResult.DarwTime << endl;
	cout << Tabs(2) << " Final Winner : " << GameResult.NameWinner << endl;
	cout << Tabs(2) << "______________________________________________" << endl;



}

void GameOver()
{


	cout << Tabs(2) << "______________________________________________" << endl;
	cout << Tabs(2) << " +++ G  a  m  e  O  v  e   r +++ " << endl;
	cout << Tabs(2) << "______________________________________________" << endl;

}

void RestScreen()
{


	system("cls");
	system("color 0F");


}

void StartGame()
{

	char Playagin = 'Y';

	do
	{

		PlayGame(ReadNumberInRange());
		PrintRoundInfo();
		GameOver();
		PrintGameResult();

		cout << Tabs(2) << " Do You Want To Play agin? Y/N : " << endl;
		cin >> Playagin;

	} while (Playagin == 'Y' || Playagin == 'y');

}


int main()
{


	srand((unsigned)time(NULL));
	StartGame();

}
